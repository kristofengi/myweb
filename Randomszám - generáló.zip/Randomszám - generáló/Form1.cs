﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace CR7F1C___ZH1 //Név: Engi Kristóf      Neptun: CR7F1C
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int[] iaCR7F1C = new int[1000];
        int szamlalo;
        OpenFileDialog ofd = new OpenFileDialog();

        private void button1_Click(object sender, EventArgs e)
        {
            int darab = 0;
            ofd.Filter = "Szöveges fájlok(*.txt)|*.txt";
            if (ofd.ShowDialog()==DialogResult.OK)
            {
                StreamReader sr = new StreamReader(ofd.FileName);
                textBox1.Clear();
                szamlalo = 0;
                iaCR7F1C = new int[1000];
                string ideiglenes = "";
                while (ideiglenes!=null)
                {
                    ideiglenes = sr.ReadLine();
                    if (ideiglenes!=null)
                    {
                        if (ideiglenes!="")
                        {
                            darab++;
                            int iIdeiglenes = int.Parse(ideiglenes);
                            if (darab%2==0)
                            {
                                iaCR7F1C[szamlalo] = iIdeiglenes;
                                szamlalo++;
                                textBox1.Text += iIdeiglenes + "\r\n";
                            }
                        }
                    }
                }
                sr.Close();
            }
            else
            {
                label1.Text = "Nem választottál fájlt.";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int max = iaCR7F1C[0];
            int min = iaCR7F1C[0];
            int minmaxosszeg = 0;
            double dOsszeg = 0;
            double dAtlag = 0;
            for (int i = 0; i < szamlalo; i++)
            {
                if (iaCR7F1C[i]>max)
                {
                    max = iaCR7F1C[i];
                }
                dOsszeg += iaCR7F1C[i];
            }
            for (int i = 0; i < szamlalo; i++)
            {
                if (iaCR7F1C[i]<min)
                {
                    min = iaCR7F1C[i];
                }
            }
            minmaxosszeg = min + max;
            dAtlag = dOsszeg / szamlalo;
            label1.Text = "A minimum és maximum összege: " + minmaxosszeg.ToString();
            label2.Text = "A számok átlaga: " + dAtlag.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            bool vancsere = true;
            int meddig = szamlalo - 1;
            while (vancsere)
            {
                vancsere = false;
                for (int i = 0; i < meddig; i++)
                {
                    if (iaCR7F1C[i]<iaCR7F1C[i+1])
                    {
                        vancsere = true;
                        int tmp = iaCR7F1C[i];
                        iaCR7F1C[i] = iaCR7F1C[i + 1];
                        iaCR7F1C[i + 1] = tmp;

                    }
                }
                meddig--;
            }
            textBox2.Clear();
            for (int i = 0; i < szamlalo; i++)
            {
                textBox2.Text += iaCR7F1C[i].ToString() + "\r\n";
            }
        }
        Random rnd = new Random();

        private void button4_Click(object sender, EventArgs e)
        {
            int max = iaCR7F1C[0];
            int min = iaCR7F1C[0];
            for (int i = 0; i < szamlalo; i++)
            {
                if (iaCR7F1C[i] > max)
                {
                    max = iaCR7F1C[i];
                }
                
            }
            for (int i = 0; i < szamlalo; i++)
            {
                if (iaCR7F1C[i] < min)
                {
                    min = iaCR7F1C[i];
                }
            }
            int irandom = rnd.Next(min, max + 1);
            int ihany = 0;
            for (int i = 0; i < szamlalo; i++)
            {
                if (irandom%iaCR7F1C[i]==0)
                {
                    ihany++;
                }
            }
            label3.Text = ihany.ToString() + " darab számnak többszöröse a generált szám";
            label4.Text = irandom.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
