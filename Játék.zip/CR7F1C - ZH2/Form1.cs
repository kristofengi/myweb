﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CR7F1C___ZH2
{
    //CR7F1C
    //Engi Kristóf
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Rectangle recjatekos;
        SolidBrush ecsetjatekos = new SolidBrush(Color.Yellow);

        int iElkapott;

        List<Labda> labdak;

        private void ujjatek()
        {
            timer1.Interval = 1;
            timer1.Enabled = true;

            timer2.Interval = 1000;
            timer2.Enabled = true;

            iElkapott = 0;

            recjatekos = new Rectangle(0, 0, 40, 40);

            progressBar1.Value = 0;

            labdak = new List<Labda>();
            labdak.Add(new Labda(ClientSize.Width, ClientSize.Height));
            labdak.Add(new Labda(ClientSize.Width, ClientSize.Height));

            this.Invalidate();
        }

        private void vege()
        {
            timer1.Enabled = false;
            timer2.Enabled = false;
        }


        private void timer1_Tick(object sender, EventArgs e)
        {
            
            Point pontKurzor = this.PointToClient(Cursor.Position);
            recjatekos.X = pontKurzor.X - 20;
            recjatekos.Y = pontKurzor.Y - 20;

            foreach (Labda aktLabda in labdak)
            {
                aktLabda.Mozgas();
            }

            

            foreach (Labda aktLabda in labdak)
            {
                aktLabda.Pattan(ClientSize.Width);
            }
            foreach (Labda aktLabda in labdak)
            {
                if (aktLabda.Leesett(ClientSize.Height))
                {
                    vege();
                }
            }
            for (int i = labdak.Count - 1; i >= 0; i--)
            {
                if (labdak[i].Elkapas(recjatekos))
                {
                    labdak.RemoveAt(i);
                    labdak.Add(new Labda(ClientSize.Width, ClientSize.Height));
                    iElkapott++;
                }
                if (labdak[i].Pattante(ClientSize.Width))
                {
                    labdak.Add(new Labda(ClientSize.Width, ClientSize.Height));
                }
            }

            label1.Text = "Eddig elkapott labdák: " + iElkapott.ToString();


            this.Invalidate();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            if (timer1.Enabled)
            {
                e.Graphics.FillEllipse(ecsetjatekos, recjatekos);
                foreach (Labda aktLabda in labdak)
                {
                    aktLabda.Rajz(e.Graphics);
                }
            }
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space)
            {
                ujjatek();
            }
            if (e.KeyCode == Keys.Escape)
            {
                Application.Exit();
            }
            
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            labdak.Add(new Labda(ClientSize.Width, ClientSize.Height));

            progressBar1.Value++;
            if (progressBar1.Value == 10)
            {
                vege();
                MessageBox.Show("Gratulálok, nyertél. Elkapott labdák száma: " + iElkapott.ToString(), "Győzelem!",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

            this.Invalidate();
        }

        
    }
}
