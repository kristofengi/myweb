﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace CR7F1C___ZH2
{

    class Labda
    {
        private Rectangle recLabda;
        private static Random rnd = new Random();
        private SolidBrush ecsetLabda = new SolidBrush(Color.FromArgb(rnd.Next(0, 256), rnd.Next(0, 256), rnd.Next(0, 256)));
        private int iSebX, iSebY;


        public Labda(int iSzel, int iMag)
        {
            recLabda = new Rectangle(rnd.Next(0, iSzel - 20), 0, 20, 20);
            iSebY = rnd.Next(1, 4);
            iSebX = rnd.Next(-5, 6);
        }

        public void Mozgas()
        {
            recLabda.X += iSebX;
            recLabda.Y += iSebY;
        }

        public void Rajz(Graphics rajzlap)
        {
            rajzlap.FillEllipse(ecsetLabda, recLabda);
        }

        public void Pattan(int iSzel)
        {
            if (0 > recLabda.Left | recLabda.Right > iSzel)
            {
                iSebX = -iSebX;
            }
        }

        public bool Elkapas(Rectangle jatekos)
        {
            if (recLabda.IntersectsWith(jatekos))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool Pattante(int iSzel)
        {
            if (0 > recLabda.Left | recLabda.Right > iSzel)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        public bool Leesett(int iMag)
        {
            if (recLabda.Bottom > iMag)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
